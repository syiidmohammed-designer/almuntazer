# مجموعة المنتظر — الموقع العام
GitHub Pages: Settings → Pages → Deploy from a branch → main / (root)
